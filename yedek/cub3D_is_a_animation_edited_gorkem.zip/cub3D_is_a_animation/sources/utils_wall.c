/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils_wall.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gsever <gsever@student.42kocaeli.com.tr    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/05 14:53:55 by gsever            #+#    #+#             */
/*   Updated: 2023/01/24 22:31:59 by gsever           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/cub3d.h"

int	is_wall(t_main *main, double x, double y)
{
	int	xX;
	int	yY;

	if (x < 0 || x > main->map.max_x || y < 0 || y > main->map.max_y)
		return (1);
	xX = floor(x);
	yY = floor(y);
	//printf("xX:%d, yY:%d\n", xX, yY);
	if (main->map.map[yY][xX] != '1')
		return (0);
	return (1);
}

int is_wall_v2(t_main *main, double x, double y)
{
	int xX;
	int yY;

	xX = (int)floor(x);
	yY = (int)floor(y);
	if (ft_strchr("L", main->map.map[yY][xX]) && main->sprite.is_hit == false)
	{
		main->sprite.is_hit = true;
		main->sprite.s_x = xX + 0.5;
		main->sprite.s_y = yY + 0.5;
		main->sprite.distance = main->ray.distance;
		printf("distance -> sprite:%f, ray:%f\n", main->sprite.distance, main->ray.distance);
		if (main->sprite.distance == 0)
			main->sprite.distance = sqrt(((main->ply.pos_x - main->sprite.s_x)*(main->ply.pos_x - main->sprite.s_x)) + ((main->ply.pos_y - main->sprite.s_y)*(main->ply.pos_y - main->sprite.s_y)));
	}
	return (ft_strchr("0NSEWL", main->map.map[yY][xX]) == NULL);
}
