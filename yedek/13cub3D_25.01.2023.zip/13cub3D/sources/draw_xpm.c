/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   draw_xpm.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gsever <gsever@student.42kocaeli.com.tr    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/14 18:48:49 by gsever            #+#    #+#             */
/*   Updated: 2023/01/25 01:39:27 by gsever           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

// void	put_xpm_to_sprite(t_main *main, int location, t_xpm xpm)
// {
	// mlx_put_image_to_window(main->mlx.ptr, main->mlx.win, xpm.img.ptr, location, main->key.screen_mid);
// }

// void	draw_xpm_to_sprite(t_main *main, int location, int oran, t_xpm xpm)
// {
// 	int	
// }

// void	draw_xpm_to_sprite(t_main *main, int location, int oran, t_xpm xpm) // sütun bilgisi var lakin genişlik bilgisi yok.
// {
// 	int i = -1;
// 	static int l = 0;
// 	int find_pixel = ((main->sprite.s_y - floor(main->sprite.s_y)) * (xpm.width)); // resmin hangi sütununu çizeceğini belirtiyor.
// 	int img_loc = (xpm.width * (xpm.height / 2)) + find_pixel - l;
// 	l++;
// 	if (l > xpm.width)
// 		l = 0;
// 	oran = (int)((double)((xpm.height / 2) * BOX_SIZE) / main->sprite.distance); // resmin sürekli bize bakması için dist sprite boyunca aynı değere sahip olmalı.
// 	while (++i < oran / 2)
// 	{
// 		if ((location - (WINDOW_W * i)) >= 0) //yukarı
// 			main->screen.addr[(location - (WINDOW_W * i))] = xpm.img.addr[img_loc - xpm.width * (int)((double)i * ((double)xpm.width / (double)(oran * 2)))];
// 		if ((WINDOW_H * WINDOW_W) >= (location + (WINDOW_W * i))) // aşağı
// 			main->screen.addr[(location + (WINDOW_W * i))] = xpm.img.addr[img_loc - xpm.width * (int)((double)i * ((double)xpm.width / (double)(oran * 2)))];
// 	}
// }

void	draw_xpm_to_sprite(t_main *main, int ray_count, t_xpm xpm)
{
	main->sprite.distance = main->sprite.distance * (double)BOX_SIZE * ((double)WINDOW_H / (double)WINDOW_W);// burada normal uzakligina ulasiyor main->sprite.distance.
	int	location = (WINDOW_W * main->key.screen_mid) - ray_count;// screen'ki yatay sekildeki konumumuz. ----------[-]
	// int	location = (main->key.screen_mid) - ray_count;// screen'ki yatay sekildeki konumumuz. ----------[-]
	int	oran = (((double)WINDOW_H / 2.0) / main->sprite.distance) * (double)BOX_SIZE;// ekrandaki yuksekligimiz.
	if (oran > 4000)
		oran = 4000;
	int	find_pixel = ((main->ray.pos_x - floor(main->ray.pos_x)) * xpm.width); // resimdeki pixel sütun konumunu bulur.
	int	img_loc = (xpm.width * (xpm.height / 2)) + find_pixel;// buraya kadar da img'deki konumu bulduk.
	int i = -1;
	while(++i < oran)
	{
		if ((location - (WINDOW_W * i)) >= 0) //yukarı
			main->screen.addr[(location - (WINDOW_W * i))] = xpm.img.addr[img_loc - xpm.width * (int)((double)i * (double)xpm.width / (double)(oran * 2))];
		if ((WINDOW_H * WINDOW_W) >= (location + (WINDOW_W * i))) // aşağı
			main->screen.addr[(location + (WINDOW_W * i))] = xpm.img.addr[img_loc + xpm.width * (int)((double)i * (double)xpm.width / (double)(oran * 2))];
	}
		// my_mlx_pixel_put(&main->screen, location, i, xpm.img.addr[img_loc - xpm.width * (int)((double)i * (double)xpm.width / (double)(oran * 2))]);

	// while (++i < oran)
	// {
	// 	int asdf = 200;
	// 	if (asdf == 1)
	// 		break;
	// 	if ((location - (WINDOW_W * i)) >= 0) //yukarı
	// 		my_mlx_pixel_put(&main->screen, asdf--, i, xpm.img.addr[img_loc - xpm.width * (int)((double)i * (double)xpm.width / (double)(oran * 2))]);
	// 		// main->screen.addr[(location - (WINDOW_W * i))] = xpm.img.addr[img_loc - xpm.width * (int)((double)i * (double)xpm.width / (double)(oran * 2))];
	// 	// if ((WINDOW_H * WINDOW_W) >= (location + (WINDOW_W * i))) // aşağı
	// 		// main->screen.addr[(location + (WINDOW_W * i))] = xpm.img.addr[img_loc + xpm.width * (int)((double)i * (double)xpm.width / (double)(oran * 2))];
	// }
}

void	draw_xpm_to_wall(t_main *main, int location, int oran, t_xpm xpm)
{
	int	i = -1;
	int find_pixel = 0;
	if (main->ray.hit_h == true)// && main->ray.dir_y == -1)
		find_pixel = ((main->ray.pos_x - floor(main->ray.pos_x)) * xpm.width); // resimdeki pixel sütun konumunu bulur.
	else if (main->ray.hit_v == true)
		find_pixel = ((main->ray.pos_y - floor(main->ray.pos_y)) * xpm.width); // resimdeki pixel sütun konumunu bulur.
	int img_loc = (xpm.width * xpm.height / 2) + find_pixel;
	while (++i < oran)
	{
		if ((location - (WINDOW_W * i)) >= 0) //yukarı
			main->screen.addr[(location - (WINDOW_W * i))] = xpm.img.addr[img_loc - xpm.width * (int)((double)i * (double)xpm.width / (double)(oran * 2))];//xpm.img.addr[img_loc - (xpm.width * ((i / (WINDOW_H / main->xpm[0].height)) % xpm.height))];
		if ((WINDOW_H * WINDOW_W) >= (location + (WINDOW_W * i))) // aşağı
			main->screen.addr[(location + (WINDOW_W * i))] = xpm.img.addr[img_loc + xpm.width * (int)((double)i * (double)xpm.width / (double)(oran * 2))];//xpm.img.addr[img_loc + (xpm.width * ((i / (WINDOW_H / main->xpm[0].height)) % xpm.height))];
	}
}

// /**
//  * @brief 
//  * 
//  * Gerekli argler:
//  * 	 Hangi duvara carptiginin bilinmesi gerekiyor;
//  * 		dir_x, dir_y, hit_v, hit_h, hit_x, hit_y
//  * bpp: 32, line_size: 256, endian: 0
//  * @param main 
//  * @param location 
//  * @param color 
//  */
// void	draw_xpm_to_wall(t_main *main, int location, int oran, t_xpm xpm)
// {
// 	int	i = -1;
// 	if (main->ray.hit_h == true && main->ray.dir_y == -1)
// 	{
// 		int	find_pixel = ((main->ray.pos_x - floor(main->ray.pos_x)) * xpm.width);
// 		i = -1;
// 		while (++i <= oran && (WINDOW_H * WINDOW_W) >= (location + (WINDOW_W * i)) && (location + (WINDOW_W * i)) >= 0)
// 		{
// 			main->screen.addr[location + (WINDOW_W * i)] = xpm.img.addr[find_pixel + (xpm.width * ((i / (WINDOW_H / main->xpm[0].height)) % xpm.height))];
// 		}
// 	}
// 	// else
// 	// {
// 	// 	(void)xpm;
// 	// 	while (++i <= oran && i <= WINDOW_H)
// 	// 		main->screen.addr[location + (WINDOW_W * i)] = 0xffffff;
// 	// }
// }



//////////////////////////////////////////////////////////////////////////////////////////////////
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sprite_bonus.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cclaude <cclaude@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 18:04:34 by cclaude           #+#    #+#             */
/*   Updated: 2020/01/17 17:56:51 by cclaude          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*
#include "cub3d_bonus.h"

void	ft_sdraw(t_all *s, t_spr spr)
{
	if (spr.c == '7')
		ft_ldraw(s, spr.a * s->win.x / 66, spr.d);
	else if (spr.c == '8')
		ft_idraw(s, spr.a * s->win.x / 66, spr.d);
	else if (spr.c == '9')
		ft_ddraw(s, spr.a * s->win.x / 66, spr.d);
	else if (ft_is(ENEMY, spr.c))
		ft_edraw(s, spr.a * s->win.x / 66, spr.d, spr.f);
	else if (spr.c == '-')
		ft_edraw(s, spr.a * s->win.x / 66, spr.d, 3);
}

double	ft_slocate(t_all *s, t_spr spr)
{
	double	angle;

	spr.x = (spr.x - s->pos.x) / spr.d;
	spr.y = (spr.y - s->pos.y) / spr.d;
	if (spr.y <= 0)
		angle = acos(spr.x) * 180 / M_PI;
	else
		angle = 360 - acos(spr.x) * 180 / M_PI;
	angle = s->dir.a - angle + 33;
	if (angle >= 180)
		angle -= 360;
	else if (angle <= -180)
		angle += 360;
	return (angle);
}

void	ft_sorder(t_all *s)
{
	t_spr	tmp;
	int		i;
	int		j;

	i = 0;
	while (i < s->map.spr - 1)
	{
		j = i + 1;
		while (j < s->map.spr)
		{
			if (s->spr[i].d < s->spr[j].d)
			{
				tmp = s->spr[i];
				s->spr[i] = s->spr[j];
				s->spr[j] = tmp;
			}
			j++;
		}
		i++;
	}
}

int		ft_slist(t_all *s)
{
	int		i;
	int		j;
	int		k;

	free(s->spr);
	if (!(s->spr = malloc(sizeof(t_spr) * s->map.spr)))
		return (-1);
	i = 0;
	j = 0;
	while (j < s->map.y)
	{
		k = 0;
		while (k < s->map.x)
		{
			if (ft_is(SPRITE, s->map.tab[j][k]))
			{
				s->spr[i].y = (double)j + 0.5;
				s->spr[i].x = (double)k + 0.5;
				s->spr[i++].c = s->map.tab[j][k];
			}
			k++;
		}
		j++;
	}
	return (1);
}

void	ft_seen(t_all *s, t_spr *spr)
{
	int		i;
	double	x;
	double	y;
	char	c;

	i = 1;
	x = spr->x - s->pos.x;
	y = spr->y - s->pos.y;
	while (i < 100)
	{
		s->hit.x = s->pos.x + x * i / 100;
		s->hit.y = s->pos.y + y * i / 100;
		c = s->map.tab[(int)floor(s->hit.y)][(int)floor(s->hit.x)];
		if (ft_is(WALL, c) || ft_is(DOOR, c))
		{
			spr->v = 0;
			spr->f = 0;
			return ;
		}
		i++;
	}
	spr->v++;
	ft_getshot(s, spr);
}

void	ft_sprite(t_all *s)
{
	int		i;

	i = 0;
	while (i < s->map.spr)
	{
		s->spr[i].d = hypot(s->spr[i].x - s->pos.x, s->spr[i].y - s->pos.y);
		s->spr[i].a = ft_slocate(s, s->spr[i]);
		if (ft_is(ENEMY, s->spr[i].c))
			ft_seen(s, &s->spr[i]);
		i++;
	}
	ft_sorder(s);
	i = 0;
	while (i < s->map.spr)
	{
		s->hit.x = s->spr[i].x;
		s->hit.y = s->spr[i].y;
		ft_sdraw(s, s->spr[i]);
		i++;
	}
	free(s->stk);
}
*/



////////////////////////////////////////////////////////////
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sprite_draw_bonus.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cclaude <cclaude@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 18:04:34 by cclaude           #+#    #+#             */
/*   Updated: 2020/01/17 12:35:42 by cclaude          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*
#include "cub3d_bonus.h"

unsigned int	ft_spixel(t_all *s, int index, unsigned int col)
{
	int	t;
	int	r;
	int	g;
	int	b;

	if (col >= NONE)
		return (s->img.adr[index]);
	else if (col < 256 * 256 * 256)
		return (ft_shadow(s, col));
	t = col / (256 * 256 * 256);
	r = (col / (256 * 256) % 256) * (1 - (double)t / 256);
	g = (col / 256 % 256) * (1 - (double)t / 256);
	b = (col % 256) * (1 - (double)t / 256);
	r += (s->img.adr[index] / (256 * 256) % 256) * ((double)t / 256);
	g += (s->img.adr[index] / 256 % 256) * ((double)t / 256);
	b += (s->img.adr[index] % 256) * ((double)t / 256);
	col = r * 256 * 256 + g * 256 + b;
	return (ft_shadow(s, col));
}

void			ft_idraw(t_all *s, int loc, double dist)
{
	unsigned int	col;
	double			size;
	int				index;
	int				i;
	int				j;

	size = s->win.y / dist / 2;
	loc = loc - size / 2;
	i = 0;
	while (i < size)
	{
		j = 0;
		while ((loc + i >= 0 && loc + i < s->win.x) &&
				(j < size && s->stk[loc + i].d > dist))
		{
			col = 64 * floor(64 * (double)j / size) + (double)i / size * 64;
			col = s->tex.i[col];
			index = loc + i + (s->win.y / 2 + j) * s->win.x;
			if (index < s->win.x * s->win.y)
				s->img.adr[index] = ft_spixel(s, index, col);
			j++;
		}
		i++;
	}
}

void			ft_ddraw(t_all *s, int loc, double dist)
{
	unsigned int	col;
	double			size;
	int				index;
	int				i;
	int				j;

	size = s->win.y / dist;
	loc = loc - size / 2;
	i = 0;
	while (i < size)
	{
		j = 0;
		while ((loc + i >= 0 && loc + i < s->win.x) &&
				(j < size && s->stk[loc + i].d > dist))
		{
			col = 64 * floor(64 * (double)j / size) + (double)i / size * 64;
			col = s->tex.j[col];
			index = loc + i + (s->win.y / 2 - (int)size / 2 + j) * s->win.x;
			if (index < s->win.x * s->win.y)
				s->img.adr[index] = ft_spixel(s, index, col);
			j++;
		}
		i++;
	}
}

void			ft_ldraw(t_all *s, int loc, double dist)
{
	unsigned int	col;
	double			size;
	int				index;
	int				i;
	int				j;

	size = s->win.y / dist / 2;
	loc = loc - size / 2;
	i = 0;
	while (i < size)
	{
		j = 0;
		while ((loc + i >= 0 && loc + i < s->win.x) &&
				(j < size && s->stk[loc + i].d > dist))
		{
			col = 128 * floor(128 * (double)j / size) + (double)i / size * 128;
			col = s->tex.k[col];
			index = loc + i + (s->win.y / 2 + j) * s->win.x;
			if (index < s->win.x * s->win.y)
				s->img.adr[index] = ft_spixel(s, index, col);
			j++;
		}
		i++;
	}
}

void			ft_edraw(t_all *s, int loc, double dist, int frame)
{
	unsigned int	col;
	double			size;
	int				index;
	int				i;
	int				j;

	size = s->win.y / dist;
	loc = loc - size / 2;
	i = 0;
	while (i < size)
	{
		j = 0;
		while ((loc + i >= 0 && loc + i < s->win.x) &&
				(j < size && s->stk[loc + i].d > dist))
		{
			col = 256 * floor(64 * (double)j / size) + (double)i / size * 64;
			col = s->tex.g[col + frame * 64];
			index = loc + i + (s->win.y / 2 - (int)size / 2 + j) * s->win.x;
			if (index < s->win.x * s->win.y)
				s->img.adr[index] = ft_spixel(s, index, col);
			j++;
		}
		i++;
	}
}
*/